package lab2;

public class runGame {
public static void main(String[] args){
	new reversi();
}
}
