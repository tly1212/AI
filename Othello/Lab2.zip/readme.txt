1.	The main method is contained in file "runGame.java"
2.	javac runGame.java
	java runGame