package lab2;

public enum Move {
    EMPTY, LIGHT, DARK;
}


