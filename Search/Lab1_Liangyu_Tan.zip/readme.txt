how to compile and run the code:
1. javac PathOfIntrenetFile filname.java
2. java filname